package chat;

public class Server 
{
	public static void main(String[] args) 
	{
		Host new_Game = new Host();
		new_Game.ServerOpen();
	}
}